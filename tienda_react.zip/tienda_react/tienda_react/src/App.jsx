import { useEffect, useState } from 'react'
import './App.css'
import FormularioFactura from './FormularioFactura'

function App() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [usuario, setUsuario] = useState(null)
  const [cargando, setCargando] = useState(true)
  const [pagina, setPagina] = useState('inicio')

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (!token) {
      setCargando(false)
      return
    }
    fetch('http://127.0.0.1:8000/api/user', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    })
      .then(respuesta => respuesta.json())
      .then(datos => {
        setUsuario(datos)
        setCargando(false)
      })
  }, [])
  async function iniciarSesion(e) {
    e.preventDefault()

    const respuesta = await fetch('http://127.0.0.1:8000/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        email: email,
        password: password
      })
    })

    const datos = await respuesta.json()

    localStorage.setItem('token', datos.token)
    setUsuario(datos.user)
  }

  async function cerrarSesion() {
    const token = localStorage.getItem('token')

    await fetch('http://127.0.0.1:8000/api/logout', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/json'
      }
    })

    localStorage.removeItem('token')
    setUsuario(null)
  }

  if (cargando) {
    return <h1>Cargando.....</h1>
  }
  if (!usuario) {
    return (
      <div className='login'>
        <h2>Inciar Sesión</h2>
        <form onSubmit={iniciarSesion}>
          <label>Correo</label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
          <label>Contraseña</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
          <button type='submit'>Iniciar Sesión</button>
        </form>
      </div>
    )
  }
  if (pagina === 'formulario') {
    return (
      <FormularioFactura
        volver={() => setPagina('inicio')}
      />
    )
  }

  return (
    <div>
      <h1>Bienvenido, {usuario.name}</h1>
      <p>Correo: {usuario.email}</p>
      <button type='button' onClick={() => setPagina('formulario')}>
        Crear factura
      </button>
      <button type='button' onClick={cerrarSesion}>
        Cerrar sesión
      </button>
    </div>
  )
}

export default App