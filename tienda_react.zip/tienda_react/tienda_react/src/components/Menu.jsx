import React from "react";

function Menu({ usuario, onLogout }) {

    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-primary shadow">
            <div className="container">

                <a className="navbar-brand fw-bold" href="#inicio">
                    Mi Tienda
                </a>
                <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#menuPrincipal"
                    aria-controls="menuPrincipal"
                    aria-expanded="false"
                    aria-label="Mostrar menú"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>

                <div
                    className="collapse navbar-collapse"
                    id="menuPrincipal"
                >

                    <ul className="navbar-nav me-auto mb-2 mb-lg-0">

                        <li className="nav-item">
                            <a
                                className="nav-link"
                                href="#inicio"
                            >
                                Inicio
                            </a>
                        </li>

                        <li className="nav-item">
                            <a
                                className="nav-link"
                                href="#productos"
                            >
                                Productos
                            </a>
                        </li>

                        <li className="nav-item">
                            <a
                                className="nav-link"
                                href="#tabla"
                            >
                                Lista
                            </a>
                        </li>

                        <li className="nav-item">
                            <a
                                className="nav-link"
                                href="#factura"
                            >
                                Crear factura
                            </a>
                        </li>

                    </ul>

                    <span className="navbar-text text-white me-3">
                        {usuario?.name}
                    </span>

                    <button
                        className="btn btn-light"
                        onClick={onLogout}
                    >
                        Cerrar sesión
                    </button>

                </div>
            </div>
        </nav>
    );
}

export default Menu;
