import React, { useState } from "react";
import api from "../services/api";

function Login({ onLogin }) {

    const [correo, setCorreo] = useState("");
    const [contrasena, setContrasena] = useState("");
    const [error, setError] = useState("");
    const [cargando, setCargando] = useState(false);

    async function manejarLogin(e) {
        e.preventDefault();

        setError("");
        setCargando(true);

        try {

            const respuesta = await api.post("/login", {
                email: correo,
                password: contrasena
            });

            const usuario = respuesta.data.user;
            const token = respuesta.data.token;

            // Guardar el token
            localStorage.setItem("token", token);

            // Enviar el usuario a App.jsx
            onLogin(usuario);

        } catch (error) {

            console.error("Error de login:", error);

            if (error.response?.status === 401) {

                setError("Correo o contraseña incorrectos.");

            } else if (error.response?.data?.message) {

                setError(error.response.data.message);

            } else {

                setError("No se pudo conectar con el servidor.");

            }

        } finally {

            setCargando(false);

        }
    }

    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-5">

                    <div className="card shadow">
                        <div className="card-body">

                            <h2 className="text-center mb-4">
                                Iniciar Sesión
                            </h2>

                            {error && (
                                <div className="alert alert-danger">
                                    {error}
                                </div>
                            )}

                            <form onSubmit={manejarLogin}>

                                <div className="mb-3">
                                    <label className="form-label">
                                        Correo
                                    </label>

                                    <input
                                        type="email"
                                        className="form-control"
                                        value={correo}
                                        onChange={(e) =>
                                            setCorreo(e.target.value)
                                        }
                                        required
                                    />
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">
                                        Contraseña
                                    </label>

                                    <input
                                        type="password"
                                        className="form-control"
                                        value={contrasena}
                                        onChange={(e) =>
                                            setContrasena(e.target.value)
                                        }
                                        required
                                    />
                                </div>

                                <button
                                    type="submit"
                                    className="btn btn-primary w-100"
                                    disabled={cargando}
                                >
                                    {cargando
                                        ? "Iniciando sesión..."
                                        : "Iniciar Sesión"}
                                </button>

                            </form>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}

export default Login;
