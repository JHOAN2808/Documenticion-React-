import { useEffect, useState } from "react";
import api from "../services/api";

function ListaProductos() {

    const [productos, setProductos] = useState([]);
    const [cargando, setCargando] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {

        api.get("/productos")
            .then((respuesta) => {

                console.log("Productos:", respuesta.data);

                setProductos(respuesta.data);
                setCargando(false);

            })
            .catch((error) => {

                console.error("Error productos:", error);

                setError(
                    error.response?.data?.message ||
                    "No se pudieron cargar los productos."
                );

                setCargando(false);

            });

    }, []);

    if (cargando) {
        return (
            <div className="container mt-5 text-center">
                <h3>Cargando productos...</h3>
            </div>
        );
    }

    if (error) {
        return (
            <div className="container mt-5">
                <div className="alert alert-danger text-center">
                    {error}
                </div>
            </div>
        );
    }

    return (
        <div className="container mt-5">

            <h2 className="text-center mb-4">
                Lista de productos
            </h2>

            <div className="table-responsive">

                <table className="table table-striped table-hover table-bordered align-middle">

                    <thead className="table-primary">

                        <tr>
                            <th>ID</th>
                            <th>Producto</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>IVA</th>
                        </tr>

                    </thead>

                    <tbody>

                        {productos.map((producto) => (

                            <tr key={producto.producto_id}>

                                <td>
                                    {producto.producto_id}
                                </td>

                                <td className="fw-bold">
                                    {producto.nombre_producto}
                                </td>

                                <td>
                                    {producto.descripcion}
                                </td>

                                <td>
                                    ${Number(
                                        producto.precio_unitario
                                    ).toLocaleString("es-CO")}
                                </td>

                                <td>
                                    {producto.stock}
                                </td>

                                <td>
                                    {producto.iva_porcentaje}%
                                </td>

                            </tr>

                        ))}

                    </tbody>

                </table>

            </div>

        </div>
    );
}

export default ListaProductos;
