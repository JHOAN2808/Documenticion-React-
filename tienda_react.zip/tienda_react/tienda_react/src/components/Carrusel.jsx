import React from "react";

import LaptopLenovo from "../assets/laptop lenovo.jpg";
import MouseLogitech from "../assets/mouse logitech.jpg";
import TecladoLogitech from "../assets/teclado logitech.jpg";

function Carrusel() {

    return (
        <div
            id="carruselProductos"
            className="carousel slide mb-5"
            data-bs-ride="carousel"
        >

            <div className="carousel-indicators">

                <button
                    type="button"
                    data-bs-target="#carruselProductos"
                    data-bs-slide-to="0"
                    className="active"
                    aria-current="true"
                    aria-label="Laptop Lenovo"
                ></button>

                <button
                    type="button"
                    data-bs-target="#carruselProductos"
                    data-bs-slide-to="1"
                    aria-label="Mouse Logitech"
                ></button>

                <button
                    type="button"
                    data-bs-target="#carruselProductos"
                    data-bs-slide-to="2"
                    aria-label="Teclado Logitech"
                ></button>

            </div>

            <div className="carousel-inner">

                <div className="carousel-item active">
                    <img
                        src={LaptopLenovo}
                        className="d-block w-100"
                        alt="Laptop Lenovo"
                        style={{
                            height: "350px",
                            objectFit: "contain"
                        }}
                    />

                    <div className="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded">
                        <h5>Laptop Lenovo</h5>
                        <p>Computadora portátil de alta gama.</p>
                    </div>
                </div>

                <div className="carousel-item">
                    <img
                        src={MouseLogitech}
                        className="d-block w-100"
                        alt="Mouse Logitech"
                        style={{
                            height: "350px",
                            objectFit: "contain"
                        }}
                    />

                    <div className="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded">
                        <h5>Mouse Logitech</h5>
                        <p>Periférico de alta calidad para tu computadora.</p>
                    </div>
                </div>

                <div className="carousel-item">
                    <img
                        src={TecladoLogitech}
                        className="d-block w-100"
                        alt="Teclado Logitech"
                        style={{
                            height: "350px",
                            objectFit: "contain"
                        }}
                    />

                    <div className="carousel-caption d-none d-md-block bg-dark bg-opacity-50 rounded">
                        <h5>Teclado Logitech</h5>
                        <p>Periférico de alta calidad para tu computadora.</p>
                    </div>
                </div>

            </div>

            <button
                className="carousel-control-prev"
                type="button"
                data-bs-target="#carruselProductos"
                data-bs-slide="prev"
            >
                <span className="carousel-control-prev-icon"></span>
                <span className="visually-hidden">
                    Anterior
                </span>
            </button>

            <button
                className="carousel-control-next"
                type="button"
                data-bs-target="#carruselProductos"
                data-bs-slide="next"
            >
                <span className="carousel-control-next-icon"></span>
                <span className="visually-hidden">
                    Siguiente
                </span>
            </button>

        </div>
    );
}

export default Carrusel;
