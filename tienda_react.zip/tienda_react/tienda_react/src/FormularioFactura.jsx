import { useEffect, useState } from "react"
import 'bootstrap/dist/css/bootstrap.min.css'
import jsPDF from "jspdf"

function FormularioFactura({ volver }) {
    const [numeroFactura, setNumeroFactura] = useState('')
    const [fechaEmision, setFechaEmision] = useState('')
    const [metodoPago, setMetodoPago] = useState('Efectivo')
    const [clientes, setClientes] = useState([])
    const [clienteSeleccionado, setClienteSeleccionado] = useState('')
    const [productos, setProductos] = useState([])
    const [productoSeleccionado, setProductoSeleccionado] = useState('')
    const [precioProducto, setPrecioProducto] = useState('')
    const [ivaProducto, setIvaProducto] = useState('')
    const [cantidad, setCantidad] = useState(1)
    const [productosFactura, setProductosFactura] = useState([])
    const [totalFactura, setTotalFactura] = useState(0)
    const [subtotalFactura, setSubtotalFactura] = useState(0)
    const [ivaFactura, setIvaFactura] = useState(0)
    const [mostrarModal, setMostrarModal] = useState(false)
    const [mostrarFactura, setMostrarFactura] = useState(false)
    const [mostrarProductos, setMostrarProductos] = useState(false)
    const [mostraPago, setMostraPago] = useState(false)

    useEffect(() => {
        console.log('EJECUTANDO PETICIÓN DE CLIENTES')

        const token = localStorage.getItem('token')
        fetch('http://127.0.0.1:8000/api/cliente', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            }
        })
            .then(respuesta => respuesta.json())
            .then(datos => {
                setClientes(datos)
            })
    }, [])

    useEffect(() => {
        const token = localStorage.getItem('token')
        fetch('http://127.0.0.1:8000/api/producto', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            }
        })
            .then(respuesta => respuesta.json())
            .then(datos => {
                setProductos(datos)
            })
    }, [])

    useEffect(() => {
        let subtotalFactura = 0
        let ivaFactura = 0
        let totalFactura = 0


        console.log('Productos de la factura:', productosFactura)
        productosFactura.forEach(producto => {
            const subtotal =
                Number(producto.precio) * Number(producto.cantidad)

            const valorIva =
                subtotal * Number(producto.iva) / 100

            const totalProducto =
                subtotal + valorIva

            subtotalFactura = subtotalFactura + subtotal
            ivaFactura = ivaFactura + valorIva
            totalFactura = totalFactura + totalProducto
        })
        setSubtotalFactura(subtotalFactura)
        setIvaFactura(ivaFactura)
        setTotalFactura(totalFactura)
    }, [productosFactura])

    useEffect(() => {
        const token = localStorage.getItem('token')
        fetch('http://127.0.0.1:8000/api/factura', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            }
        })
            .then(respuesta => respuesta.json())
            .then(datos => {
                let siguienteNumero = 1
                datos.forEach(factura => {
                    const numero = factura.numero_factura
                    if (numero && numero.startsWith('FAC-')) {
                        const parteNumero = Number(numero.replace('FAC-', ''))
                        if (parteNumero >= siguienteNumero) {
                            siguienteNumero = parteNumero + 1
                        }
                    }
                })

                const numeroFormateado = String(siguienteNumero).padStart(3, '0')
                setNumeroFactura(`FAC-${numeroFormateado}`)
            })
    }, [])

    function agregarProducto() {
        if (!productoSeleccionado) {
            return
        }
        const producto = productos.find(
            producto => producto.producto_id == productoSeleccionado
        )
        if (!producto) {
            return
        }
        console.log('Producto encontrado:', producto)
        setProductosFactura(productosAnteriores => {
            const productoExistente = productosAnteriores.find(
                producto => producto.producto_id == productoSeleccionado
            )
            if (productoExistente) {
                return productosAnteriores.map(
                    producto => {
                        if (producto.producto_id == productoSeleccionado) {
                            return {
                                ...producto,
                                cantidad: cantidad
                            }
                        }
                        return producto
                    }
                )
            } else {
                const nuevoProducto = {
                    producto_id: producto.producto_id,
                    nombre: producto.nombre_producto,
                    cantidad: cantidad,
                    precio: producto.precio_unitario,
                    iva: producto.iva_porcentaje
                }
                return [
                    ...productosAnteriores,
                    nuevoProducto
                ]
            }
        })
    }

    function crearFactura(e) {
        e.preventDefault()
        setMostrarModal(true)
    }

    async function confirmarFactura() {
        const token = localStorage.getItem('token')
        const datosFactura = {
            numero_factura: numeroFactura,
            fecha_emision: fechaEmision,
            cliente_id: clienteSeleccionado,
            subtotal: subtotalFactura,
            total_iva: ivaFactura,
            total_pagar: totalFactura,
            metodo_pago: metodoPago,
            productos: productosFactura.map(producto => ({
                producto_id: producto.producto_id,
                cantidad: producto.cantidad,
                precio_venta: producto.precio
            }))
        }
        const respuesta = await fetch('http://127.0.0.1:8000/api/factura', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            },
            body: JSON.stringify(datosFactura)
        })

        const datos = await respuesta.json()
        console.log('respuesta del servidor:', datos)
        if (respuesta.ok) {
            setMostrarModal(false)
            setMostrarFactura(true)
        } else {
            console.log('Error al guardar factura')
        }
    }

    async function nuevaFactura() {
        setFechaEmision('')
        setClienteSeleccionado('')
        setProductoSeleccionado('')
        setPrecioProducto('')
        setIvaProducto('')
        setCantidad(1)
        setProductosFactura([])
        setSubtotalFactura(0)
        setIvaFactura(0)
        setTotalFactura(0)
        setMetodoPago('Efectivo')

        const token = localStorage.getItem('token')
        const respuesta = await fetch('http://127.0.0.1:8000/api/factura', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Accept': 'application/json'
            }
        })

        const datos = await respuesta.json()
        let siguienteNumero = 1

        datos.forEach(factura => {
            const numero = factura.numero_factura
            if (numero && numero.startsWith('FAC-')) {
                const parteNumero = Number(numero.replace('FAC-', ''))
                if (parteNumero >= siguienteNumero) {
                    siguienteNumero = parteNumero + 1
                }
            }
        })
        const numeroFormateado = String(siguienteNumero).padStart(3, '0')
        setNumeroFactura(`FAC-${numeroFormateado}`)
        setMostrarFactura(false)
    }

    function generarPDF() {
        const cliente = clientes.find(
            cliente => cliente.cliente_id == clienteSeleccionado
        )
        const pdf = new jsPDF()

        pdf.text('Factura', 105, 20)
        pdf.text(`Numero de facturas: ${numeroFactura}`, 20, 40)
        pdf.text(`Fecha de emision: ${fechaEmision}`, 20, 50)
        pdf.text(`Cliente: ${cliente?.nombre} ${cliente?.apellido}`, 20, 60)
        pdf.text('Productos', 105, 80)

        let posicion = 95

        productosFactura.forEach(producto => {
            pdf.text(`Producto: ${producto.nombre}`, 20, posicion)
            posicion = posicion + 10
            pdf.text(`Cantidad: ${producto.cantidad}`, 20, posicion)
            posicion = posicion + 10
            pdf.text(`Precio: ${producto.precio}`, 20, posicion)
            posicion = posicion + 10
            pdf.text(`IVA: ${producto.iva}%`, 20, posicion)
            posicion = posicion + 15
        })

        pdf.text('Pago', 105, posicion)
        posicion = posicion + 15
        pdf.text(`Subtotal: ${subtotalFactura}`, 20, posicion)
        posicion = posicion + 10
        pdf.text(`IVA total: ${ivaFactura}`, 20, posicion)
        posicion = posicion + 10
        pdf.text(`Total: ${totalFactura}`, 20, posicion)
        posicion = posicion + 10
        pdf.text(`Metodo de pago: ${metodoPago}`, 20, posicion)
        pdf.save(`Factura-${numeroFactura}.pdf`)
    }

    if (mostrarFactura) {
        const cliente = clientes.find(
            cliente => cliente.cliente_id == clienteSeleccionado
        )
        return (
            <div className="factura_contenedor">
                <div className="factura">
                    <h1>Factura</h1>
                    <div className="datos_factura">
                        <p>Número de factura: {numeroFactura}</p>
                        <p>Fecha de emisión: {fechaEmision}</p>
                        <p>Cliente: {
                            clientes.find(cliente => cliente.cliente_id == clienteSeleccionado)?.nombre
                        } {
                                clientes.find(cliente => cliente.cliente_id == clienteSeleccionado)?.apellido
                            }</p>
                    </div>
                    <h2>Productos</h2>
                    <div className="seccion_colapsable">
                        <button type="button" className="boton_colapsable" onClick={() => setMostrarProductos(!mostrarProductos)}>
                            Productos {mostrarProductos ? '▲' : '▼'}
                        </button>
                        {mostrarProductos && (
                            <div className="productos_factura">
                                {productosFactura.map(producto => (
                                    <div className="producto_factura" key={producto.producto_id}>
                                        <p>Producto: {producto.nombre}</p>
                                        <p>Cantidad: {producto.cantidad}</p>
                                        <p>Precio: {producto.precio}</p>
                                        <p>IVA: {producto.iva}%</p>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                    <h2>Pago</h2>
                    <div className="seccion_colapsable">
                        <button type="button" className="boton_colapsable" onClick={() => setMostraPago(!mostraPago)}>
                            Pago {mostraPago ? '▲' : '▼'}
                        </button>
                        {mostraPago && (
                            <div className="pago_factura">
                                <p>Subtotal: {subtotalFactura}</p>
                                <p>IVA total: {ivaFactura}</p>
                                <p>Total: {totalFactura}</p>
                                <p>Metodo de pago: {metodoPago}</p>
                            </div>
                        )}
                    </div>
                    <button type="button" onClick={generarPDF}>
                        Generar PDF
                    </button>
                    <button type="button" onClick={nuevaFactura}>
                        Volver
                    </button>
                </div>
            </div>
        )
    }
    return (
        <div className="formulario_contenedor">
            <div className="formulario_factura">
                <h1>Crear factura</h1>
                <form onSubmit={crearFactura}>
                    <label>Número de factura</label>
                    <input type="text" value={numeroFactura} readOnly required />
                    <label>Fecha de emisión</label>
                    <input type="datetime-local" value={fechaEmision} onChange={(e) => setFechaEmision(e.target.value)} required />
                    <label>Cliente</label>
                    <select value={clienteSeleccionado} onChange={(e) => setClienteSeleccionado(e.target.value)} required>
                        <option value="">
                            Seleccione un cliente
                        </option>
                        {clientes.map(cliente => (
                            <option key={cliente.cliente_id} value={cliente.cliente_id}>
                                {cliente.nombre} {cliente.apellido}
                            </option>
                        ))}
                    </select>
                    <label>Producto</label>
                    <select value={productoSeleccionado} onChange={(e) => {
                        const id = e.target.value
                        setProductoSeleccionado(id)
                        const producto = productos.find(
                            producto => producto.producto_id == id
                        )
                        if (producto) {
                            setPrecioProducto(producto.precio_unitario)
                            setIvaProducto(producto.iva_porcentaje)
                        } else {
                            setPrecioProducto('')
                            setIvaProducto('')
                        }
                    }} required>
                        <option value="">
                            Seleccione un producto
                        </option>
                        {productos.map(producto => (
                            <option key={producto.producto_id} value={producto.producto_id}>
                                {producto.nombre_producto}
                            </option>
                        ))}
                    </select>
                    <label>Precio</label>
                    <input type="text" value={precioProducto} readOnly />
                    <label>Iva</label>
                    <input type="text" value={ivaProducto} readOnly />
                    <label>Cantidad</label>
                    <input type="number" min="1" value={cantidad} onChange={(e) => setCantidad(Number(e.target.value))} />
                    <button type="button" onClick={agregarProducto}>
                        Agregar producto
                    </button>
                    <label>Subtotal</label>
                    <input type="text" value={subtotalFactura} readOnly />
                    <label>Iva total</label>
                    <input type="text" value={ivaFactura} readOnly />
                    <label>Precio total</label>
                    <input type="text" value={totalFactura} readOnly />
                    <label>Método de pago</label>
                    <select value={metodoPago} onChange={(e) => setMetodoPago(e.target.value)}>
                        <option>Efectivo</option>
                        <option>Tarjeta</option>
                        <option>Transferencia</option>
                        <option>Nequi/Daviplata</option>
                    </select>
                    <button type="submit">
                        Crear factura
                    </button>
                </form>
                {mostrarModal && (
                    <div className="modal d-block" tabIndex={-1}>
                        <div className="modal-dialog">
                            <div className="modal-content">
                                <div className="modal-header">
                                    <h5 className="modal-title">
                                        Confirmar factura
                                    </h5>
                                </div>
                                <div className="modal-body">
                                    <p>¿Está seguro de que desea crear esta factura?</p>
                                </div>
                                <div className="modal-footer">
                                    <button type="button" className="btn btn-secondary" onClick={() => setMostrarModal(false)}>
                                        Cancelar
                                    </button>
                                    <button type="button" className="btn btn-primary" onClick={confirmarFactura}>Confirmar</button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                <button type="button" onClick={volver}>
                    Volver
                </button>
            </div>
        </div>
    )
}

export default FormularioFactura